# Modules

import pygame
import pygame_gui

import time
import discord

client = discord.Client(intents=discord.Intents.all())


# Inititalise Pygame

pygame.init()
pygame.font.init()

# Variables



Window = "Loading"



Window_Name = ""
Icon_Name = "Logo.png"

Default_Font = pygame.font.SysFont("Comic Sans MS", 30)


Screen = pygame.display.set_mode((1280,720))
clock = pygame.time.Clock()
running = True


Screen_X = 1280
Screen_Y = 720


pygame.display.set_caption(Window_Name)
Icon = pygame.image.load(Icon_Name)

pygame.display.set_icon(Icon)


Token = ""


#  ////////           OBJECT STORAGE             \\\\\\\\\\\\\\\\\\\ #



@client.event
async def on_ready():
    print(f'{client.user} is connected to the following server:\n')
    for server in client.guilds:
        print(f'{server.name}(id: {server.id})')





MANAGER = pygame_gui.UIManager((Screen_X,Screen_Y))

TEXT_INPUT = pygame_gui.elements.UITextEntryLine(relative_rect=pygame.Rect((25, 25), (900, 30)), manager=MANAGER, object_id="#Token")








def ShowTextGraphics(Text, X, Y, Padding):


    Text_Surface = Default_Font.render(Text, False, (0,0,0))

    Screen.blit(Text_Surface, (X+Padding,Y+Padding))

def ShowImageGraphics(Image, X, Y, Size):


    ##Image_Loaded = pygame.image.load(Image) 

    ##pygame.transform.scale(Image_Loaded, Size, dest_surface=None)
       
    ##Screen.blit(Image_Loaded, (X, Y))

    Image_Surface = pygame.image.load(Image)

    Image_Surface = pygame.transform.scale(Image_Surface, (Size,Size))

    Screen.blit(Image_Surface, (X,Y))
    

Width = 0
Height = 0

def Main():

    #placehold
    print("banana")

pygame.key.set_repeat(200, 25)







while running:

    # Events

    UI_REFRESHRATE = clock.tick(30)/2000
    
    
    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        if Window == "Main":

            MANAGER.process_events(event)

    if Window == "Main":

        MANAGER.update(UI_REFRESHRATE)


      

        if event.type == pygame_gui.UI_TEXT_ENTRY_FINISHED:

            Token = event.text

            print("banana")

            client.run(Token)

            

    Screen.fill("White")    



    if Window == "Loading":

        pygame.display.set_caption("Loading...")        

        Screen.fill("Black")

        
        pygame.display.flip()

        clock.tick(30)

        
        if Window == "Loading":

            time.sleep(1.5)

            Screen.fill("White")

            Window = "Main"

    if Window == "Main":

        pygame.display.set_caption("Discord Bot Server")
        MANAGER.draw_ui(Screen)

    if Window == "Main" and Token != "":
        Screen.fill("White")
        ShowTextGraphics(("Token: " + Token), 0, 0, 25 )

        ShowTextGraphics(("Your Bot Should Be Online And Ready To Go!!!"), 0, 25, 25 )
    if Window == "Main" and Token == "":
        ShowTextGraphics(("Discord Bot Token..."), 0, 35, 25 )
    
    

    # Render

    pygame.display.flip()

    clock.tick(30)

    #Main()


pygame.quit()
exit()
